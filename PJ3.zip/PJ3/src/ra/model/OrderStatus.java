package ra.model;

public enum OrderStatus {
    WAITING, CONFIRM, DELIVERY, SUCCESS, CANCEL;
}
