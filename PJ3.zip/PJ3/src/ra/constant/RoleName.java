package ra.constant;

import java.io.Serializable;

public enum RoleName implements Serializable {
    ADMIN, USER;
}
