package ra.constant;

import java.io.Serializable;

public enum Status implements Serializable {
    BLOCK, ACTIVE, INACTIVE;
}
