package ra.service;

import ra.model.Catalog;

public interface ICatalogService extends IService<Catalog>{
}
